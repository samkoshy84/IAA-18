library(fGarch)
library(dplyr)
library(aTSA)

# Change the path! 
setwd("D:\\MSA Spring\\Financial analytics\\Homework\\2\\finproject\\")

# Reading data
# The dataframes my_data, stock_prices, stock_returns are for
# conducting LM tests and choosing the best companies for volatility forecast
stocks <- read.csv("Stocks.csv", header = TRUE)
stocks <- stocks %>% select(ends_with("r"))
stocks <- stocks[2:1035,]
lagrange <- data.frame('company' = names(stocks), 'p.value' = rep(NA, times = 30))

# This piece of code estimates ARMA(0,0) model and conducts Portmonteau-test for ARCH effects
for(i in 1:30)
{
  model <- arima(stocks[,i], order = c(0,0,0))
  test.value <- arch.test(model, output = F)
  test.value <- as.data.frame(test.value)
  lagrange[i,2] <- test.value[1,3]
}

lagrange2 <- lagrange[order(lagrange[,2], decreasing = FALSE),]
# from viewing the head of lagrange2 dataframe, we identify that
# best companies are CVX, XOM, HD, and JNJ since they have lowest p-value

best.companies <- stocks[, c("CVX_r", "XOM_r", "HD_r", "JNJ_r", "PFE_r")]

garch_compare <- function(firm)
{
  GARCH.N <- garchFit(formula = ~ garch(1,1), data = best.companies[,firm], cond.dist = "norm", trace = F)
  summary(GARCH.N)
  
  GARCH.t <- garchFit(formula = ~ garch(1,1), data = best.companies[,firm], cond.dist = "std", trace = F)
  summary(GARCH.t)
  
  Skew.GARCH.t <- garchFit(formula = ~ garch(1,1), data = best.companies[,firm], cond.dist = "sstd", trace = F)
  summary(Skew.GARCH.t)
  
  Skew.GARCH.N <- garchFit(formula = ~ garch(1,1), data = best.companies[,firm], cond.dist = "snorm", trace = F)
  summary(Skew.GARCH.N)
}

# For CVX we have t-GARCH model with lowest AIC -6.02477
# For XOM we have t-GARCH model with lowest AIC -6.35097
# For HD we have skewed t-GARCH model with lowest AIC -6.3116
# For JNJ we have t-GARCH mode with AIC -6.7070
# For PFE we have t-GARCH mode with AIC -6.4422

# Since the appropriate GARCH models have been identified, we forecast standard deviations now
fit.CVX <- garchFit(formula = ~ garch(1,1), data = best.companies[,"CVX_r"], cond.dist = "std", trace = F)
fit.XOM <- garchFit(formula = ~ garch(1,1), data = best.companies[,"XOM_r"], cond.dist = "std", trace = F)
fit.HD <- garchFit(formula = ~ garch(1,1), data = best.companies[,"HD_r"], cond.dist = "sstd", trace = F)
fit.JNJ <- garchFit(formula = ~ garch(1,1), data = best.companies[,"JNJ_r"], cond.dist = "std", trace = F)
fit.PFE <- garchFit(formula = ~ garch(1,1), data = best.companies[,"PFE_r"], cond.dist = "std", trace = F)

# The forecasts
pred.CVX <- predict(fit.CVX, 5)
pred.XOM <- predict(fit.XOM, 5)
pred.HD <- predict(fit.HD, 5)
pred.JNJ <- predict(fit.JNJ, 5)
pred.PFE <- predict(fit.PFE, 5)